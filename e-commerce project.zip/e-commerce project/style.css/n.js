function sendotp(){
    var dig='0123456789';
    let OTP='';
    for(let i=0;i<dig.length;i++){
       OTP=Math.random();
    }
    return OTP;
 }
 sendotp()
 sendotp()